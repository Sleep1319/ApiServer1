package com.api_board.restapiboard.exception;

public class MemberNotFoundException extends RuntimeException{
}
