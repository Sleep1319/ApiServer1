package com.api_board.restapiboard.dto.category;

import com.api_board.restapiboard.domain.category.Category;
import com.api_board.restapiboard.exception.CategoryNotFoundException;
import com.api_board.restapiboard.repository.CategoryRepository;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Optional;

@ApiModel(value = "카테고리 생성 요청")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CategoryCreateRequest {

    @ApiModelProperty(value = "카테고리 명", notes = "카테고리 명을 입력해주세요", required = true, example = "my category")
    @NotBlank(message = "카테고리 명을 입력해주세요.")
    @Size(min = 2, max = 30, message = "카테고리 명의 길이는 2글자에서 30글자 입니다.")
    private String name;

    @ApiModelProperty(value = "부모 카테고리 아이디", notes = "부모 카테고리 아이디를 입력해주세요", required = false, example = "7")
    private Long parentId;

    /**
     * 부모 카테고리는 null일 수 있다 (root카테고리)
     * 즉 parentId가 null일때 Category생성자 두번째 인자의 부모 Category도 null이여야 하고
     * null이 아니면 두번째 인자 부모 카테고리도 null이 아니여야 한다
     *
     * ofNullable에 주어진 값이 null이면 map은 수행 되지 않는다 orElse의 null반환
     * ofNullable에 주어진 값이 null이 아니지만 없는 카테고리면 예외 발생
     *
     */
    public static Category toEntity(CategoryCreateRequest req, CategoryRepository categoryRepository) {
        return new Category(req.getName(),
                Optional.ofNullable(req.getParentId())
                        .map(id -> categoryRepository.findById(id).orElseThrow(CategoryNotFoundException::new))
                        .orElse(null));
    }

}
