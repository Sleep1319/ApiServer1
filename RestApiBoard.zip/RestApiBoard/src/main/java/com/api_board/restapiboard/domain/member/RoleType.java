package com.api_board.restapiboard.domain.member;

public enum RoleType {
    ROLE_NORMAL, ROLE_SPECIAL_SELLER, ROLE_SPECIAL_BUYER, ROLE_ADMIN
}
