package com.api_board.restapiboard.exception;

public class AccessDeniedException extends RuntimeException {
    public AccessDeniedException(String s) {
    }
}
