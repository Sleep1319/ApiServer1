package com.api_board.restapiboard.exception;

public class CommentNotFoundException extends RuntimeException{
}
