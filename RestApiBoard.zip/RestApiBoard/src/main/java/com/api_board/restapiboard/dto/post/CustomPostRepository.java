package com.api_board.restapiboard.dto.post;

import org.springframework.data.domain.Page;

public interface CustomPostRepository {
    Page<PostSimpleDTO> findAllByCondition(PostReadCondition cond);
}
