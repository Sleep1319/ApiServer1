package com.api_board.restapiboard.dto.rsponse;

public interface Result {
}
