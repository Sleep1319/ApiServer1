package com.api_board.restapiboard.dto.post;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PostUpdateResponse {
    private Long id;
}
