package com.api_board.restapiboard.service;

import com.api_board.restapiboard.dto.alarm.AlarmInfoDTO;

public interface AlarmService {
    void alarm(AlarmInfoDTO infoDTO);
}
