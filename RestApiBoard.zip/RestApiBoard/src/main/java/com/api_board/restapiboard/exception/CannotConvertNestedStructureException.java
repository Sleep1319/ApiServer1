package com.api_board.restapiboard.exception;

public class CannotConvertNestedStructureException extends RuntimeException{
    public CannotConvertNestedStructureException(String message){
        super(message);
    }
}
