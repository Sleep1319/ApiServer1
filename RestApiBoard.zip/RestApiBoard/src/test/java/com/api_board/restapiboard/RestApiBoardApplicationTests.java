package com.api_board.restapiboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiBoardApplicationTests {

    @Test
    void contextLoads() {
    }

}
